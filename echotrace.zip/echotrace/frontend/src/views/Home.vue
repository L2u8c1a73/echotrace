<template>
    <div>
      <h1>EchoTrace OSINT</h1>
      <input v-model="url" placeholder="Inserisci URL" />
      <button @click="scan">Scansiona</button>
      <ul>
        <li v-for="(title, index) in results" :key="index">{{ title }}</li>
      </ul>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        url: '',
        results: [],
      };
    },
    methods: {
      async scan() {
        const res = await fetch(`/api/scan?url=${encodeURIComponent(this.url)}`);
        const data = await res.json();
        this.results = data.titles || [];
      },
    },
  };
  </script>
  