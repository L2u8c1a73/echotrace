<template>
    <div class="min-h-screen bg-black text-blue-400 font-orbitron p-6">
      <header class="border-b border-blue-800 pb-4 mb-6">
        <h1 class="text-4xl tracking-wide glow-text">EchoTrace OSINT</h1>
      </header>
      <Home />
    </div>
  </template>
  
  <script>
  import Home from './views/Home.vue'
  export default { components: { Home } }
  </script>
  
  <style>
  @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@500&display=swap');
  
  .glow-text {
    text-shadow: 0 0 8px #00f0ff;
  }
  </style>
  