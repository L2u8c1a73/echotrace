#!/bin/bash

echo "🚀 Avvio di EchoTrace..."
echo "📱 L'applicazione sarà disponibile su http://localhost:3000"
echo ""

# Check if Python 3 is available
if command -v python3 &> /dev/null; then
    echo "✅ Python 3 trovato"
    python3 simple_server.py
else
    echo "❌ Python 3 non trovato. Installa Python 3 per continuare."
    exit 1
fi 