<template>
    <div class="bg-gray-900 p-6 rounded-lg border border-blue-700 shadow-glow">
      <h2 class="text-2xl text-tronblue mb-4 glow-text">Timeline delle scansioni</h2>
      <ul class="space-y-4">
        <li v-for="scan in scans" :key="scan._id" class="border-b border-blue-600 pb-2">
          <p class="text-blue-300">{{ formatDate(scan.date) }}</p>
          <p class="text-neonglow">{{ scan.url }}</p>
        </li>
      </ul>
    </div>
  </template>
  
  <script>
  export default {
    props: ['scans'],
    methods: {
      formatDate(date) {
        return new Date(date).toLocaleString('it-IT')
      }
    }
  }
  </script>
  
  <style scoped>
  .glow-text {
    text-shadow: 0 0 6px #00ffff;
  }
  .shadow-glow {
    box-shadow: 0 0 8px #00ffff;
  }
  </style>
  