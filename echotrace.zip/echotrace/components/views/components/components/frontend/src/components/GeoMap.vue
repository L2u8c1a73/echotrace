<template>
    <div class="rounded-lg overflow-hidden border border-blue-700 shadow-glow">
      <h2 class="text-2xl text-tronblue mb-2 glow-text p-4">Origine scansioni</h2>
      <div id="map" class="h-96 w-full"></div>
    </div>
  </template>
  
  <script>
  import L from 'leaflet'
  import 'leaflet/dist/leaflet.css'
  
  export default {
    mounted() {
      const map = L.map('map').setView([43.7696, 11.2558], 4) // Firenze come centro
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map)
  
      // Esempio: marker scansione
      L.marker([48.8566, 2.3522]).addTo(map).bindPopup('Scansione da Parigi')
      L.marker([51.5074, -0.1278]).addTo(map).bindPopup('Scansione da Londra')
    }
  }
  </script>
  
  <style scoped>
  #map {
    filter: brightness(0.8) contrast(1.2);
  }
  </style>
  