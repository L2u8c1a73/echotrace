module.exports = {
    theme: {
      extend: {
        colors: {
          tronblue: '#00ffff',
          tronblack: '#000000',
          neonglow: '#00f0ff'
        },
        fontFamily: {
          orbitron: ['Orbitron', 'sans-serif']
        }
      }
    }
  }
  