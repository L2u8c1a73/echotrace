<template>
    <div class="space-y-6">
      <Logo />
      <input v-model="url" placeholder="Inserisci URL"
        class="w-full px-4 py-2 bg-gray-900 text-blue-300 border border-blue-600 rounded focus:outline-none focus:ring focus:ring-blue-500" />
      <button @click="scan"
        class="px-6 py-2 bg-blue-700 text-black font-bold uppercase rounded hover:bg-blue-400 transition duration-200 shadow-glow">
        Scansiona
      </button>
      <ul class="mt-4 space-y-2">
        <li v-for="(title, index) in results" :key="index" class="border-b border-blue-700 pb-1">{{ title }}</li>
      </ul>
    </div>
  </template>
  
  <script>
  import Logo from '../components/Logo.vue'
  export default {
    data() {
      return { url: '', results: [] }
    },
    methods: {
      async scan() {
        const res = await fetch(`/api/scan?url=${encodeURIComponent(this.url)}`)
        const data = await res.json()
        this.results = data.titles || []
      }
    }
  }
  </script>
  
  <style scoped>
  .shadow-glow {
    box-shadow: 0 0 6px #00ffff;
  }
  </style>

<template>
    <div class="space-y-8">
      <Logo />
      <!-- Input e pulsante scansione -->
      <!-- ... -->
      <Timeline :scans="scanHistory" />
      <GeoMap />
    </div>
  </template>
  
  <script>
  import Timeline from '../components/Timeline.vue'
  import GeoMap from '../components/GeoMap.vue'
  import Logo from '../components/Logo.vue'
  
  export default {
    components: { Timeline, GeoMap, Logo },
    data() {
      return {
        scanHistory: [] // Da popolare con fetch da MongoDB
      }
    },
    mounted() {
      fetch('/api/history')
        .then(res => res.json())
        .then(data => this.scanHistory = data)
    }
  }
  </script>
  
  