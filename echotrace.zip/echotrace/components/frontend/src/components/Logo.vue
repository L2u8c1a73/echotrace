<template>
  <div class="flex justify-center items-center mb-6">
    <div class="logo-container">
      <svg width="160" height="160" viewBox="0 0 200 200" class="logo-svg">
        <!-- Cerchio esterno con effetto glow -->
        <circle cx="100" cy="100" r="85" stroke="#00ffff" stroke-width="3" fill="none" class="outer-ring" />
        <circle cx="100" cy="100" r="80" stroke="#00ffff" stroke-width="6" fill="none" class="main-ring" />
        
        <!-- Cerchio interno con gradiente -->
        <defs>
          <radialGradient id="logoGradient" cx="50%" cy="50%" r="50%">
            <stop offset="0%" style="stop-color:#00ffff;stop-opacity:0.3" />
            <stop offset="70%" style="stop-color:#0066cc;stop-opacity:0.1" />
            <stop offset="100%" style="stop-color:#000000;stop-opacity:0" />
          </radialGradient>
        </defs>
        
        <!-- Cerchio di sfondo con gradiente -->
        <circle cx="100" cy="100" r="70" fill="url(#logoGradient)" />
        
        <!-- Elementi decorativi TRON -->
        <line x1="30" y1="100" x2="50" y2="100" stroke="#00ffff" stroke-width="2" class="decorative-line" />
        <line x1="150" y1="100" x2="170" y2="100" stroke="#00ffff" stroke-width="2" class="decorative-line" />
        <line x1="100" y1="30" x2="100" y2="50" stroke="#00ffff" stroke-width="2" class="decorative-line" />
        <line x1="100" y1="150" x2="100" y2="170" stroke="#00ffff" stroke-width="2" class="decorative-line" />
        
        <!-- Punti angolari -->
        <circle cx="30" cy="30" r="3" fill="#00ffff" class="corner-dot" />
        <circle cx="170" cy="30" r="3" fill="#00ffff" class="corner-dot" />
        <circle cx="30" cy="170" r="3" fill="#00ffff" class="corner-dot" />
        <circle cx="170" cy="170" r="3" fill="#00ffff" class="corner-dot" />
        
        <!-- Testo principale -->
        <text x="50%" y="45%" text-anchor="middle" fill="#00ffff" font-size="18" font-weight="bold" class="main-text">EchoTrace</text>
        
        <!-- Sottotitolo -->
        <text x="50%" y="60%" text-anchor="middle" fill="#00aaff" font-size="10" class="subtitle">Web Scanner</text>
        
        <!-- Elemento centrale pulsante -->
        <circle cx="100" cy="100" r="8" fill="#00ffff" class="center-dot" />
      </svg>
    </div>
  </div>
</template>

<style scoped>
.logo-container {
  position: relative;
  display: inline-block;
}

.logo-svg {
  filter: drop-shadow(0 0 8px #00ffff) drop-shadow(0 0 16px #00ffff);
  animation: logoGlow 3s ease-in-out infinite alternate;
}

.outer-ring {
  animation: rotate 20s linear infinite;
  stroke-dasharray: 5, 5;
  opacity: 0.6;
}

.main-ring {
  animation: pulse 2s ease-in-out infinite;
}

.decorative-line {
  animation: fadeInOut 2s ease-in-out infinite;
  opacity: 0.7;
}

.corner-dot {
  animation: blink 1.5s ease-in-out infinite;
}

.main-text {
  filter: drop-shadow(0 0 4px #00ffff);
  animation: textGlow 2s ease-in-out infinite alternate;
}

.subtitle {
  opacity: 0.8;
  animation: subtitlePulse 3s ease-in-out infinite;
}

.center-dot {
  animation: centerPulse 1s ease-in-out infinite;
}

@keyframes logoGlow {
  0% { filter: drop-shadow(0 0 8px #00ffff) drop-shadow(0 0 16px #00ffff); }
  100% { filter: drop-shadow(0 0 12px #00ffff) drop-shadow(0 0 24px #00ffff) drop-shadow(0 0 32px #00ffff); }
}

@keyframes rotate {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}

@keyframes pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.7; }
}

@keyframes fadeInOut {
  0%, 100% { opacity: 0.7; }
  50% { opacity: 1; }
}

@keyframes blink {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.3; }
}

@keyframes textGlow {
  0% { filter: drop-shadow(0 0 4px #00ffff); }
  100% { filter: drop-shadow(0 0 8px #00ffff) drop-shadow(0 0 12px #00ffff); }
}

@keyframes subtitlePulse {
  0%, 100% { opacity: 0.8; }
  50% { opacity: 1; }
}

@keyframes centerPulse {
  0%, 100% { r: 8; opacity: 1; }
  50% { r: 12; opacity: 0.8; }
}

/* Effetto hover */
.logo-container:hover .logo-svg {
  filter: drop-shadow(0 0 16px #00ffff) drop-shadow(0 0 32px #00ffff) drop-shadow(0 0 48px #00ffff);
  transform: scale(1.05);
  transition: all 0.3s ease;
}

.logo-container:hover .main-text {
  filter: drop-shadow(0 0 8px #00ffff) drop-shadow(0 0 16px #00ffff);
}
</style>

