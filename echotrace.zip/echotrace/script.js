

// Funzione per toggle degli insight
function toggleInsight(headerElement) {
  const insightCard = headerElement.closest('.insight-card');
  const toggleButton = headerElement.querySelector('.insight-toggle');
  
  if (insightCard.classList.contains('collapsed')) {
    // Espandi
    insightCard.classList.remove('collapsed');
    insightCard.classList.add('expanded');
    toggleButton.textContent = '▲';
    toggleButton.classList.add('expanded');
  } else {
    // Collassa
    insightCard.classList.remove('expanded');
    insightCard.classList.add('collapsed');
    toggleButton.textContent = '▼';
    toggleButton.classList.remove('expanded');
  }
}

async function scanUrl() {
  const url = document.getElementById('urlInput').value;
  if (!url) {
    showError('Inserisci un URL valido');
    return;
  }

  // Aggiorna status indicator
  updateScanStatus('scanning', 'Scansione in corso...');
  
  // Mostra stato di caricamento
  const button = document.querySelector('.scan-btn');
  const originalText = button.innerHTML;
  button.innerHTML = '<span class="btn-icon">⏳</span><span class="btn-text">SCANSIONANDO...</span>';
  button.disabled = true;

  // Nascondi sezioni precedenti
  hideAllSections();

  try {
    const response = await fetch(`/api/scan?url=${encodeURIComponent(url)}`);
    const data = await response.json();
  
    if (data.error) {
      showError(`Errore: ${data.error}`);
      updateScanStatus('error', 'Errore durante la scansione');
    } else {
      displayScanResults(data);
      updateScanStatus('complete', 'Scansione completata');
    }
  } catch (error) {
    showError('Errore di connessione al server');
    updateScanStatus('error', 'Errore di connessione');
  } finally {
    // Ripristina il pulsante
    button.innerHTML = originalText;
    button.disabled = false;
  }
}

function updateScanStatus(status, message) {
  const statusIndicator = document.getElementById('statusIndicator');
  const statusText = document.getElementById('statusText');
  
  // Rimuovi classi precedenti
  statusIndicator.className = 'status-indicator';
  
  // Aggiungi classe appropriata
  statusIndicator.classList.add(status);
  statusText.textContent = message;
}

function displayScanResults(data) {
  // Mostra informazioni di rete
  displayNetworkInfo(data);
  
  // Mostra subdomain
  displaySubdomains(data.subdomains);
  
  // Mostra insights aggiuntivi
  displayAdditionalInsights(data.additional_insights);
  
  // Crea grafici dei dati
  createDataCharts(data);
  
  // Mostra porte aperte
  displayOpenPorts(data.open_ports);
  
  // Mostra vulnerabilità
  displayVulnerabilities(data.vulnerabilities);
  
  // Mostra header di sicurezza
  displaySecurityHeaders(data.security_headers);
  
  // Mostra titoli
  displayTitles(data.titles);
  
  // Mostra timestamp
  displayTimestamp(data.scan_timestamp);
  
  // Aggiorna i badge con i conteggi
  updateSectionBadges(data);
}

function updateSectionBadges(data) {
  // Aggiorna i badge delle sezioni con i conteggi
  document.getElementById('subdomainsCount').textContent = data.subdomains ? data.subdomains.length : 0;
  document.getElementById('insightsCount').textContent = data.additional_insights ? data.additional_insights.length : 0;
  document.getElementById('portsCount').textContent = data.open_ports ? data.open_ports.length : 0;
  document.getElementById('vulnsCount').textContent = data.vulnerabilities ? data.vulnerabilities.length : 0;
  document.getElementById('headersCount').textContent = data.security_headers ? Object.keys(data.security_headers).length : 0;
  document.getElementById('titlesCount').textContent = data.titles ? data.titles.length : 0;
}

function displayNetworkInfo(data) {
  document.getElementById('hostname').textContent = data.hostname || '-';
  document.getElementById('ipAddress').textContent = data.ip_address || '-';
  document.getElementById('port').textContent = data.port || '-';
  document.getElementById('protocol').textContent = data.protocol || '-';
  document.getElementById('responseTime').textContent = data.response_time_ms ? `${data.response_time_ms} ms` : '-';
  document.getElementById('serverInfo').textContent = data.server_info || '-';
  
  document.getElementById('networkInfo').style.display = 'block';
}

function displaySubdomains(subdomains) {
  const subdomainsContainer = document.getElementById('subdomains');
  subdomainsContainer.innerHTML = '';
  
  if (subdomains && subdomains.length > 0) {
    subdomains.forEach((subdomain, index) => {
      const subdomainCard = document.createElement('div');
      subdomainCard.className = 'subdomain-card';
      subdomainCard.style.animationDelay = `${index * 0.1}s`;
      subdomainCard.classList.add('fade-in');
      
      subdomainCard.innerHTML = `
        <div class="subdomain-name">${subdomain.subdomain}</div>
        <div class="subdomain-full">${subdomain.full_domain}</div>
        <div class="subdomain-type">${subdomain.type}</div>
      `;
      
      subdomainsContainer.appendChild(subdomainCard);
    });
  } else {
    const noSubdomains = document.createElement('div');
    noSubdomains.className = 'subdomain-card';
    noSubdomains.innerHTML = `
      <div class="subdomain-name">Nessun Subdomain Trovato</div>
      <div class="subdomain-full">Nessun subdomain attivo rilevato</div>
      <div class="subdomain-type">N/A</div>
    `;
    subdomainsContainer.appendChild(noSubdomains);
  }
  
  document.getElementById('subdomainsSection').style.display = 'block';
}

function displayAdditionalInsights(insights) {
  const insightsContainer = document.getElementById('additionalInsights');
  insightsContainer.innerHTML = '';
  
  if (insights && insights.length > 0) {
    // Group insights by category
    const insightsByCategory = {};
    insights.forEach(insight => {
      if (!insightsByCategory[insight.category]) {
        insightsByCategory[insight.category] = [];
      }
      insightsByCategory[insight.category].push(insight);
    });
    
    // Display insights grouped by category
    Object.entries(insightsByCategory).forEach(([category, categoryInsights]) => {
      // Create category header
      const categoryHeader = document.createElement('div');
      categoryHeader.className = 'category-header';
      categoryHeader.innerHTML = `
        <h3 style="color: var(--tron-orange); margin: 1rem 0 0.5rem 0; text-transform: uppercase; letter-spacing: 1px;">
          ${category.toUpperCase()} (${categoryInsights.length})
        </h3>
      `;
      insightsContainer.appendChild(categoryHeader);
      
      // Display insights for this category
      categoryInsights.forEach((insight, index) => {
        const insightCard = document.createElement('div');
        insightCard.className = `insight-card category-${insight.category.toLowerCase()}`;
        insightCard.style.animationDelay = `${index * 0.1}s`;
        insightCard.classList.add('fade-in');
        
        // Add count badge if available
        const countBadge = insight.count ? `<span class="count-badge">${insight.count}</span>` : '';
        
        insightCard.innerHTML = `
          <div class="insight-header" onclick="toggleInsight(this)">
            <div>
              <div class="insight-category">${insight.category}</div>
              <div class="insight-type">${insight.type} ${countBadge}</div>
            </div>
            <button class="insight-toggle">▼</button>
          </div>
          <div class="insight-content">
            <div class="insight-value">${insight.value}</div>
            <div class="insight-description">${insight.description}</div>
          </div>
        `;
        
        // Inizializza come collassato
        insightCard.classList.add('collapsed');
        
        insightsContainer.appendChild(insightCard);
      });
    });
  } else {
    const noInsights = document.createElement('div');
    noInsights.className = 'insight-card category-technology';
    noInsights.innerHTML = `
      <div class="insight-header">
        <div class="insight-category">No Insights</div>
        <div class="insight-type">No Additional Data</div>
      </div>
      <div class="insight-value">Nessun insight aggiuntivo disponibile</div>
      <div class="insight-description">Non sono stati rilevati dati aggiuntivi per questo target</div>
    `;
    insightsContainer.appendChild(noInsights);
  }
  
  document.getElementById('insightsSection').style.display = 'block';
}

function displayOpenPorts(openPorts) {
  const portsContainer = document.getElementById('openPorts');
  portsContainer.innerHTML = '';
  
  if (openPorts && openPorts.length > 0) {
    openPorts.forEach(port => {
      const portItem = document.createElement('div');
      portItem.className = 'port-item';
      portItem.innerHTML = `
        <span class="port-number">${port}</span>
        <span class="port-service">${getPortService(port)}</span>
      `;
      portsContainer.appendChild(portItem);
    });
  } else {
    const noPorts = document.createElement('div');
    noPorts.className = 'port-item';
    noPorts.textContent = 'Nessuna porta aperta trovata';
    portsContainer.appendChild(noPorts);
  }
  
  document.getElementById('portsSection').style.display = 'block';
}

function displayVulnerabilities(vulnerabilities) {
  const vulnContainer = document.getElementById('vulnerabilities');
  vulnContainer.innerHTML = '';
  
  if (vulnerabilities && vulnerabilities.length > 0) {
    vulnerabilities.forEach((vuln, index) => {
      const vulnCard = document.createElement('div');
      vulnCard.className = `vulnerability-card severity-${vuln.severity.toLowerCase()}`;
      vulnCard.style.animationDelay = `${index * 0.1}s`;
      vulnCard.classList.add('fade-in');
      
      vulnCard.innerHTML = `
        <div class="vulnerability-header">
          <div class="vulnerability-type">${vuln.type}</div>
          <div class="vulnerability-severity ${vuln.severity.toLowerCase()}">${vuln.severity}</div>
        </div>
        <div class="vulnerability-description">${vuln.description}</div>
        <div class="vulnerability-recommendation">Raccomandazione: ${vuln.recommendation}</div>
      `;
      
      vulnContainer.appendChild(vulnCard);
    });
  } else {
    const noVulns = document.createElement('div');
    noVulns.className = 'vulnerability-card severity-low';
    noVulns.innerHTML = `
      <div class="vulnerability-header">
        <div class="vulnerability-type">Nessuna Vulnerabilità</div>
        <div class="vulnerability-severity low">Sicuro</div>
      </div>
      <div class="vulnerability-description">Nessuna vulnerabilità critica rilevata</div>
      <div class="vulnerability-recommendation">Il target sembra essere configurato correttamente</div>
    `;
    vulnContainer.appendChild(noVulns);
  }
  
  document.getElementById('vulnerabilitiesSection').style.display = 'block';
}

function displaySecurityHeaders(securityHeaders) {
  const headersContainer = document.getElementById('securityHeaders');
  headersContainer.innerHTML = '';
  
  if (securityHeaders && Object.keys(securityHeaders).length > 0) {
    Object.entries(securityHeaders).forEach(([headerName, headerValue]) => {
      const isPresent = headerValue !== 'Non presente';
      const headerCard = document.createElement('div');
      headerCard.className = `header-card ${isPresent ? 'present' : 'missing'}`;
      
      headerCard.innerHTML = `
        <div class="header-status ${isPresent ? 'present' : 'missing'}"></div>
        <div class="header-name">${headerName}</div>
        <div class="header-value">${headerValue}</div>
      `;
      
      headersContainer.appendChild(headerCard);
    });
  } else {
    const noHeaders = document.createElement('div');
    noHeaders.className = 'header-card missing';
    noHeaders.innerHTML = `
      <div class="header-status missing"></div>
      <div class="header-name">Nessun Header</div>
      <div class="header-value">Nessun header di sicurezza rilevato</div>
    `;
    headersContainer.appendChild(noHeaders);
  }
  
  document.getElementById('securityHeadersSection').style.display = 'block';
}

function displayTitles(titles) {
  const resultsList = document.getElementById('results');
  resultsList.innerHTML = '';
  
  if (titles && titles.length > 0) {
    titles.forEach(title => {
      const listItem = document.createElement('li');
      listItem.textContent = title;
      resultsList.appendChild(listItem);
    });
  } else {
    const noTitles = document.createElement('li');
    noTitles.className = 'error';
    noTitles.textContent = 'Nessun titolo trovato';
    resultsList.appendChild(noTitles);
  }
  
  document.getElementById('titlesSection').style.display = 'block';
}

function displayTimestamp(timestamp) {
  document.getElementById('scanTimestamp').textContent = timestamp || '-';
}

function getPortService(port) {
  const portServices = {
    21: 'FTP',
    22: 'SSH',
    23: 'Telnet',
    25: 'SMTP',
    53: 'DNS',
    80: 'HTTP',
    110: 'POP3',
    143: 'IMAP',
    443: 'HTTPS',
    993: 'IMAPS',
    995: 'POP3S',
    3306: 'MySQL',
    5432: 'PostgreSQL',
    8080: 'HTTP-Alt',
    8443: 'HTTPS-Alt'
  };
  
  return portServices[port] || 'Unknown';
}

function hideAllSections() {
  const sections = [
    'networkInfo', 'subdomainsSection', 'insightsSection', 
    'portsSection', 'vulnerabilitiesSection', 'securityHeadersSection', 
    'titlesSection'
  ];
  
  sections.forEach(sectionId => {
    document.getElementById(sectionId).style.display = 'none';
  });
}

function showError(message) {
  // Mostra errore nel status
  updateScanStatus('error', message);
  
  // Mostra anche un alert temporaneo
  alert(message);
}

// Aggiungi event listener per Enter key
document.addEventListener('DOMContentLoaded', function() {
  const urlInput = document.getElementById('urlInput');
  urlInput.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
      scanUrl();
    }
  });
  
  // Inizializza status
  updateScanStatus('idle', 'Pronto per la scansione');
});

// Funzione per creare grafici dei dati acquisiti
function createDataCharts(scanData) {
  const chartsContainer = document.getElementById('chartsSection');
  if (!chartsContainer) return;
  
  chartsContainer.style.display = 'block';
  chartsContainer.innerHTML = `
    <div class="section-header">
      <h3>📊 Analisi Dati</h3>
      <div class="section-badge">Charts</div>
    </div>
    <div class="charts-grid">
      <div class="chart-card">
        <h4>Vulnerabilità per Severità</h4>
        <canvas id="vulnerabilityChart" width="400" height="200"></canvas>
      </div>
      <div class="chart-card">
        <h4>Porte Aperte</h4>
        <canvas id="portsChart" width="400" height="200"></canvas>
      </div>
      <div class="chart-card">
        <h4>Security Headers</h4>
        <canvas id="headersChart" width="400" height="200"></canvas>
      </div>
      <div class="chart-card">
        <h4>Distribuzione Insights</h4>
        <canvas id="insightsChart" width="400" height="200"></canvas>
      </div>
    </div>
  `;
  
  // Crea i grafici dopo che il DOM è stato aggiornato
  setTimeout(() => {
    createVulnerabilityChart(scanData.vulnerabilities);
    createPortsChart(scanData.open_ports);
    createHeadersChart(scanData.security_headers);
    createInsightsChart(scanData.additional_insights);
  }, 100);
}

function createVulnerabilityChart(vulnerabilities) {
  const ctx = document.getElementById('vulnerabilityChart');
  if (!ctx) return;
  
  const severityCounts = {
    'Alta': 0,
    'Media': 0,
    'Bassa': 0
  };
  
  vulnerabilities.forEach(vuln => {
    if (severityCounts.hasOwnProperty(vuln.severity)) {
      severityCounts[vuln.severity]++;
    }
  });
  
  new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: Object.keys(severityCounts),
      datasets: [{
        data: Object.values(severityCounts),
        backgroundColor: [
          'rgba(255, 71, 87, 0.8)',
          'rgba(255, 165, 2, 0.8)',
          'rgba(46, 213, 115, 0.8)'
        ],
        borderColor: [
          'rgba(255, 71, 87, 1)',
          'rgba(255, 165, 2, 1)',
          'rgba(46, 213, 115, 1)'
        ],
        borderWidth: 2
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          labels: {
            color: '#00ffff',
            font: {
              family: 'Courier New'
            }
          }
        }
      }
    }
  });
}

function createPortsChart(openPorts) {
  const ctx = document.getElementById('portsChart');
  if (!ctx) return;
  
  const portData = openPorts.map(port => ({
    port: port.port,
    service: port.service,
    status: 'Aperta'
  }));
  
  const labels = portData.map(p => `Porta ${p.port}`);
  const data = portData.map(p => 1); // Ogni porta aperta conta come 1
  
  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: labels,
      datasets: [{
        label: 'Porte Aperte',
        data: data,
        backgroundColor: 'rgba(0, 255, 255, 0.6)',
        borderColor: 'rgba(0, 255, 255, 1)',
        borderWidth: 1
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        y: {
          beginAtZero: true,
          ticks: {
            color: '#00ffff',
            font: {
              family: 'Courier New'
            }
          },
          grid: {
            color: 'rgba(0, 255, 255, 0.2)'
          }
        },
        x: {
          ticks: {
            color: '#00ffff',
            font: {
              family: 'Courier New'
            }
          },
          grid: {
            color: 'rgba(0, 255, 255, 0.2)'
          }
        }
      },
      plugins: {
        legend: {
          labels: {
            color: '#00ffff',
            font: {
              family: 'Courier New'
            }
          }
        }
      }
    }
  });
}

function createHeadersChart(securityHeaders) {
  const ctx = document.getElementById('headersChart');
  if (!ctx) return;
  
  const headerStatus = {
    'Presenti': 0,
    'Mancanti': 0
  };
  
  Object.values(securityHeaders).forEach(status => {
    if (status === 'present') {
      headerStatus['Presenti']++;
    } else {
      headerStatus['Mancanti']++;
    }
  });
  
  new Chart(ctx, {
    type: 'pie',
    data: {
      labels: Object.keys(headerStatus),
      datasets: [{
        data: Object.values(headerStatus),
        backgroundColor: [
          'rgba(46, 213, 115, 0.8)',
          'rgba(255, 71, 87, 0.8)'
        ],
        borderColor: [
          'rgba(46, 213, 115, 1)',
          'rgba(255, 71, 87, 1)'
        ],
        borderWidth: 2
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          labels: {
            color: '#00ffff',
            font: {
              family: 'Courier New'
            }
          }
        }
      }
    }
  });
}

function createInsightsChart(insights) {
  const ctx = document.getElementById('insightsChart');
  if (!ctx) return;
  
  const categoryCounts = {};
  insights.forEach(insight => {
    const category = insight.category;
    categoryCounts[category] = (categoryCounts[category] || 0) + 1;
  });
  
  const labels = Object.keys(categoryCounts);
  const data = Object.values(categoryCounts);
  
  new Chart(ctx, {
    type: 'radar',
    data: {
      labels: labels,
      datasets: [{
        label: 'Numero di Insights',
        data: data,
        backgroundColor: 'rgba(0, 255, 255, 0.2)',
        borderColor: 'rgba(0, 255, 255, 1)',
        borderWidth: 2,
        pointBackgroundColor: 'rgba(0, 255, 255, 1)',
        pointBorderColor: '#fff',
        pointHoverBackgroundColor: '#fff',
        pointHoverBorderColor: 'rgba(0, 255, 255, 1)'
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        r: {
          beginAtZero: true,
          ticks: {
            color: '#00ffff',
            font: {
              family: 'Courier New'
            }
          },
          grid: {
            color: 'rgba(0, 255, 255, 0.2)'
          },
          pointLabels: {
            color: '#00ffff',
            font: {
              family: 'Courier New'
            }
          }
        }
      },
      plugins: {
        legend: {
          labels: {
            color: '#00ffff',
            font: {
              family: 'Courier New'
            }
          }
        }
      }
    }
  });
}
  