#!/usr/bin/env python3
import json
import urllib.request
import sys

def test_scan(url):
    """Test the EchoTrace scan functionality"""
    try:
        # Make API request
        api_url = f"http://localhost:3000/api/scan?url={url}"
        with urllib.request.urlopen(api_url) as response:
            data = json.load(response)
        
        print(f"=== ECHOTRACE SCAN RESULTS FOR {url} ===")
        print(f"Keys found: {list(data.keys())}")
        
        # Test subdomains
        subdomains = data.get('subdomains', [])
        print(f"\n=== SUBDOMAINS ===")
        print(f"Found {len(subdomains)} subdomains:")
        for subdomain in subdomains[:5]:  # Show first 5
            print(f"  - {subdomain['subdomain']} ({subdomain['type']})")
        
        # Test additional insights
        insights = data.get('additional_insights', [])
        print(f"\n=== ADDITIONAL INSIGHTS ===")
        print(f"Found {len(insights)} insights:")
        
        # Group by category
        categories = {}
        for insight in insights:
            category = insight.get('category', 'Unknown')
            if category not in categories:
                categories[category] = []
            categories[category].append(insight)
        
        for category, category_insights in categories.items():
            print(f"  {category} ({len(category_insights)} items):")
            for insight in category_insights[:3]:  # Show first 3 per category
                print(f"    - {insight['type']}: {insight.get('count', 0)} items")
        
        # Test vulnerabilities
        vulnerabilities = data.get('vulnerabilities', [])
        print(f"\n=== VULNERABILITIES ===")
        print(f"Found {len(vulnerabilities)} vulnerabilities:")
        for vuln in vulnerabilities:
            print(f"  - {vuln['type']} ({vuln['severity']})")
        
        # Test security headers
        security_headers = data.get('security_headers', {})
        print(f"\n=== SECURITY HEADERS ===")
        print(f"Found {len(security_headers)} security headers:")
        for header, value in list(security_headers.items())[:5]:  # Show first 5
            status = "✅" if value != "Non presente" else "❌"
            print(f"  {status} {header}: {value}")
        
        # Test open ports
        open_ports = data.get('open_ports', [])
        print(f"\n=== OPEN PORTS ===")
        print(f"Found {len(open_ports)} open ports: {open_ports}")
        
        # Test titles
        titles = data.get('titles', [])
        print(f"\n=== TITLES ===")
        print(f"Found {len(titles)} titles:")
        for title in titles[:3]:  # Show first 3
            print(f"  - {title}")
        
        return True
        
    except Exception as e:
        print(f"Error testing scan: {e}")
        return False

if __name__ == "__main__":
    test_urls = [
        "https://example.com",
        "https://httpbin.org",
        "https://github.com"
    ]
    
    for url in test_urls:
        print("\n" + "="*60)
        success = test_scan(url)
        if not success:
            print(f"Failed to test {url}")
        print("="*60) 