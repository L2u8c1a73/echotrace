const express = require('express');
const axios = require('axios');
const cheerio = require('cheerio');
const router = express.Router();
const Scan = require('../models/Scan');

router.get('/', async (req, res) => {
  const { url } = req.query;
  try {
    const response = await axios.get(url);
    const $ = cheerio.load(response.data);
    const titles = [];
    $('h1, h2, h3').each((i, el) => titles.push($(el).text()));

    const newScan = new Scan({ url, titles });
    await newScan.save();

    res.json({ titles });
  } catch (err) {
    res.status(500).json({ error: 'Errore durante la scansione' });
  }
});

module.exports = router;

const mongoose = require('mongoose');

const scanSchema = new mongoose.Schema({
  url: String,
  titles: [String],
  date: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Scan', scanSchema);
