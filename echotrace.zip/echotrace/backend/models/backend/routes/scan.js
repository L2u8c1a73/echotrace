const express = require('express');
const router = express.Router();
const axios = require('axios');
const cheerio = require('cheerio');
const Scan = require('../models/Scan');

router.get('/scan', async (req, res) => {
  const { url } = req.query;
  const response = await axios.get(url);
  const $ = cheerio.load(response.data);
  const titles = [];
  $('h1,h2,h3').each((i, el) => titles.push($(el).text()));
  const newScan = new Scan({ url, titles });
  await newScan.save();
  res.json({ titles });
});

router.get('/history', async (req, res) => {
  const scans = await Scan.find().sort({ date: -1 }).limit(10);
  res.json(scans);
});

module.exports = router;
