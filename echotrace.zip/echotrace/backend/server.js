const express = require('express');
const axios = require('axios');
const cheerio = require('cheerio');
const path = require('path');

const app = express();
const PORT = 3000;

// Serve static files from the root directory
app.use(express.static(path.join(__dirname, '..')));

// API endpoint for scanning URLs
app.get('/api/scan', async (req, res) => {
  const { url } = req.query;
  if (!url) return res.status(400).json({ error: 'URL mancante' });

  try {
    const response = await axios.get(url, {
      timeout: 10000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
      }
    });
    
    const $ = cheerio.load(response.data);
    const titles = [];
    
    // Extract headings (h1, h2, h3)
    $('h1, h2, h3').each((i, el) => {
      const text = $(el).text().trim();
      if (text) {
        titles.push(text);
      }
    });
    
    res.json({ titles });
  } catch (err) {
    console.error('Errore durante la scansione:', err.message);
    res.status(500).json({ error: 'Errore durante l\'analisi: ' + err.message });
  }
});

// Serve the main page
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`🚀 EchoTrace operativo su http://localhost:${PORT}`);
  console.log(`📱 Apri il browser e vai su http://localhost:${PORT}`);
});
