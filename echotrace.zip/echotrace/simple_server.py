#!/usr/bin/env python3
import http.server
import socketserver
import urllib.request
import urllib.parse
import urllib.error
import json
import re
import socket
import threading
import time
import ssl
import base64
from urllib.parse import urlparse, parse_qs, urljoin
from concurrent.futures import ThreadPoolExecutor, as_completed

class EchoTraceHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path.startswith('/api/scan'):
            self.handle_scan_api()
        else:
            # Serve static files
            if self.path == '/':
                self.path = '/index.html'
            return http.server.SimpleHTTPRequestHandler.do_GET(self)
    
    def handle_scan_api(self):
        try:
            # Parse query parameters
            parsed_url = urlparse(self.path)
            query_params = parse_qs(parsed_url.query)
            url = query_params.get('url', [None])[0]
            
            if not url:
                self.send_error_response('URL mancante')
                return
            
            # Parse URL
            parsed_target = urlparse(url)
            hostname = parsed_target.hostname
            if not hostname:
                self.send_error_response('Hostname non valido')
                return
            port = parsed_target.port or (443 if parsed_target.scheme == 'https' else 80)
            
            # Get IP address
            try:
                ip_address = socket.gethostbyname(hostname)
            except socket.gaierror:
                ip_address = "Non risolvibile"
            
            # Fetch the webpage
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
            
            titles = []
            server_info = "Non disponibile"
            response_time = 0
            security_headers = {}
            html_content = ""
            
            try:
                start_time = time.time()
                req = urllib.request.Request(url, headers=headers)
                with urllib.request.urlopen(req, timeout=10) as response:
                    html_content = response.read().decode('utf-8')
                    response_time = round((time.time() - start_time) * 1000, 2)
                    server_info = response.headers.get('Server', 'Non specificato')
                    
                    # Check security headers
                    security_headers = self.check_security_headers(response.headers)
            except Exception as e:
                server_info = f"Errore: {str(e)}"
            
            # Extract headings using regex
            heading_patterns = [
                r'<h1[^>]*>(.*?)</h1>',
                r'<h2[^>]*>(.*?)</h2>',
                r'<h3[^>]*>(.*?)</h3>'
            ]
            
            for pattern in heading_patterns:
                matches = re.findall(pattern, html_content, re.IGNORECASE | re.DOTALL)
                for match in matches:
                    clean_text = re.sub(r'<[^>]+>', '', match).strip()
                    if clean_text:
                        titles.append(clean_text)
            
            # Scan common ports
            open_ports = self.scan_common_ports(hostname)
            
            # Scan for vulnerabilities
            vulnerabilities = self.scan_vulnerabilities(hostname, port, parsed_target.scheme, html_content, security_headers)
            
            # Discover subdomains
            subdomains = self.discover_subdomains(hostname)
            
            # Get comprehensive insights
            additional_insights = self.get_comprehensive_insights(hostname, ip_address, html_content, server_info, url)
            
            # Prepare response
            scan_result = {
                'url': url,
                'hostname': hostname,
                'ip_address': ip_address,
                'port': port,
                'protocol': parsed_target.scheme,
                'server_info': server_info,
                'response_time_ms': response_time,
                'open_ports': open_ports,
                'vulnerabilities': vulnerabilities,
                'security_headers': security_headers,
                'subdomains': subdomains,
                'additional_insights': additional_insights,
                'titles': titles,
                'scan_timestamp': time.strftime('%Y-%m-%d %H:%M:%S')
            }
            
            self.send_json_response(scan_result)
            
        except Exception as e:
            self.send_error_response(f'Errore generico: {str(e)}')
    
    def get_comprehensive_insights(self, hostname, ip_address, html_content, server_info, base_url):
        """Get comprehensive insights including email, domains, IPs, social, images"""
        insights = []
        
        # Email extraction
        email_insights = self.extract_emails(html_content)
        if email_insights:
            insights.extend(email_insights)
        
        # Domain extraction
        domain_insights = self.extract_domains(html_content, hostname)
        if domain_insights:
            insights.extend(domain_insights)
        
        # IP address extraction
        ip_insights = self.extract_ip_addresses(html_content)
        if ip_insights:
            insights.extend(ip_insights)
        
        # Social media extraction
        social_insights = self.extract_social_media(html_content)
        if social_insights:
            insights.extend(social_insights)
        
        # Image extraction
        image_insights = self.extract_images(html_content, base_url)
        if image_insights:
            insights.extend(image_insights)
        
        # Technology detection
        tech_insights = self.detect_technologies(html_content, server_info)
        if tech_insights:
            insights.extend(tech_insights)
        
        # DNS insights
        dns_insights = self.get_dns_insights(hostname, ip_address)
        if dns_insights:
            insights.extend(dns_insights)
        
        # SSL/TLS insights
        if 'https' in base_url:
            ssl_insights = self.get_ssl_insights(hostname)
            if ssl_insights:
                insights.extend(ssl_insights)
        
        return insights
    
    def extract_emails(self, html_content):
        """Extract email addresses from HTML content"""
        insights = []
        
        # Multiple email patterns
        email_patterns = [
            r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
            r'mailto:([A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,})',
            r'email["\']?\s*[:=]\s*["\']?([A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,})["\']?'
        ]
        
        all_emails = set()
        for pattern in email_patterns:
            matches = re.findall(pattern, html_content, re.IGNORECASE)
            all_emails.update(matches)
        
        if all_emails:
            # Categorize emails by domain
            email_by_domain = {}
            for email in all_emails:
                domain = email.split('@')[1] if '@' in email else 'unknown'
                if domain not in email_by_domain:
                    email_by_domain[domain] = []
                email_by_domain[domain].append(email)
            
            for domain, emails in email_by_domain.items():
                insights.append({
                    'category': 'Email',
                    'type': f'Email Addresses ({domain})',
                    'value': ', '.join(emails[:5]),  # Limit to 5 emails per domain
                    'description': f'Found {len(emails)} email(s) from {domain} domain',
                    'count': len(emails)
                })
        
        return insights
    
    def extract_domains(self, html_content, base_hostname):
        """Extract domains from HTML content"""
        insights = []
        
        # Domain patterns
        domain_patterns = [
            r'https?://([A-Za-z0-9.-]+\.[A-Z|a-z]{2,})',
            r'www\.([A-Za-z0-9.-]+\.[A-Z|a-z]{2,})',
            r'([A-Za-z0-9.-]+\.[A-Z|a-z]{2,})',
            r'href=["\']https?://([A-Za-z0-9.-]+\.[A-Z|a-z]{2,})["\']'
        ]
        
        all_domains = set()
        for pattern in domain_patterns:
            matches = re.findall(pattern, html_content, re.IGNORECASE)
            all_domains.update(matches)
        
        # Filter out the base domain and common CDNs
        filtered_domains = []
        for domain in all_domains:
            if (domain != base_hostname and 
                not domain.startswith('www.') and
                not any(cdn in domain.lower() for cdn in ['cdn', 'static', 'assets', 'img', 'images'])):
                filtered_domains.append(domain)
        
        if filtered_domains:
            # Group by TLD
            domains_by_tld = {}
            for domain in filtered_domains:
                tld = domain.split('.')[-1] if '.' in domain else 'unknown'
                if tld not in domains_by_tld:
                    domains_by_tld[tld] = []
                domains_by_tld[tld].append(domain)
            
            for tld, domains in domains_by_tld.items():
                insights.append({
                    'category': 'Domain',
                    'type': f'External Domains (.{tld})',
                    'value': ', '.join(list(set(domains))[:10]),  # Limit to 10 domains
                    'description': f'Found {len(set(domains))} external domain(s) with .{tld} TLD',
                    'count': len(set(domains))
                })
        
        return insights
    
    def extract_ip_addresses(self, html_content):
        """Extract IP addresses from HTML content"""
        insights = []
        
        # IP patterns (IPv4 and IPv6)
        ip_patterns = [
            r'\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b',  # IPv4
            r'\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b',  # IPv6
            r'ip["\']?\s*[:=]\s*["\']?((?:[0-9]{1,3}\.){3}[0-9]{1,3})["\']?'
        ]
        
        all_ips = set()
        for pattern in ip_patterns:
            matches = re.findall(pattern, html_content, re.IGNORECASE)
            all_ips.update(matches)
        
        # Filter out localhost and private IPs
        filtered_ips = []
        for ip in all_ips:
            if not self.is_private_ip(ip):
                filtered_ips.append(ip)
        
        if filtered_ips:
            insights.append({
                'category': 'IP',
                'type': 'IP Addresses Found',
                'value': ', '.join(filtered_ips[:10]),  # Limit to 10 IPs
                'description': f'Found {len(filtered_ips)} public IP address(es) in content',
                'count': len(filtered_ips)
            })
        
        return insights
    
    def is_private_ip(self, ip):
        """Check if IP is private/localhost"""
        if not ip or ip == '127.0.0.1' or ip == 'localhost':
            return True
        
        # Check for private IP ranges
        private_ranges = [
            '10.', '192.168.', '172.16.', '172.17.', '172.18.', '172.19.',
            '172.20.', '172.21.', '172.22.', '172.23.', '172.24.', '172.25.',
            '172.26.', '172.27.', '172.28.', '172.29.', '172.30.', '172.31.'
        ]
        
        return any(ip.startswith(range_prefix) for range_prefix in private_ranges)
    
    def extract_social_media(self, html_content):
        """Extract social media links and handles"""
        insights = []
        
        # Social media patterns
        social_patterns = {
            'Facebook': [
                r'facebook\.com/([A-Za-z0-9._-]+)',
                r'fb\.com/([A-Za-z0-9._-]+)',
                r'facebook["\']?\s*[:=]\s*["\']?([^"\']+)["\']?'
            ],
            'Twitter/X': [
                r'twitter\.com/([A-Za-z0-9._-]+)',
                r'x\.com/([A-Za-z0-9._-]+)',
                r'@([A-Za-z0-9._-]+)',
                r'twitter["\']?\s*[:=]\s*["\']?([^"\']+)["\']?'
            ],
            'LinkedIn': [
                r'linkedin\.com/([A-Za-z0-9._-]+)',
                r'linkedin["\']?\s*[:=]\s*["\']?([^"\']+)["\']?'
            ],
            'Instagram': [
                r'instagram\.com/([A-Za-z0-9._-]+)',
                r'instagram["\']?\s*[:=]\s*["\']?([^"\']+)["\']?'
            ],
            'YouTube': [
                r'youtube\.com/([A-Za-z0-9._-]+)',
                r'youtu\.be/([A-Za-z0-9._-]+)',
                r'youtube["\']?\s*[:=]\s*["\']?([^"\']+)["\']?'
            ],
            'TikTok': [
                r'tiktok\.com/([A-Za-z0-9._-]+)',
                r'tiktok["\']?\s*[:=]\s*["\']?([^"\']+)["\']?'
            ],
            'Telegram': [
                r't\.me/([A-Za-z0-9._-]+)',
                r'telegram["\']?\s*[:=]\s*["\']?([^"\']+)["\']?'
            ]
        }
        
        for platform, patterns in social_patterns.items():
            platform_handles = set()
            for pattern in patterns:
                matches = re.findall(pattern, html_content, re.IGNORECASE)
                platform_handles.update(matches)
            
            if platform_handles:
                insights.append({
                    'category': 'Social Media',
                    'type': f'{platform} Handles',
                    'value': ', '.join(list(platform_handles)[:5]),  # Limit to 5 handles
                    'description': f'Found {len(platform_handles)} {platform} handle(s)',
                    'count': len(platform_handles)
                })
        
        return insights
    
    def extract_images(self, html_content, base_url):
        """Extract image information from HTML content"""
        insights = []
        
        # Image patterns
        img_patterns = [
            r'<img[^>]+src=["\']([^"\']+)["\'][^>]*>',
            r'background-image:\s*url\(["\']?([^"\')\s]+)["\']?\)',
            r'data-src=["\']([^"\']+)["\']',
            r'data-original=["\']([^"\']+)["\']'
        ]
        
        all_images = set()
        for pattern in img_patterns:
            matches = re.findall(pattern, html_content, re.IGNORECASE)
            all_images.update(matches)
        
        if all_images:
            # Categorize images by type
            image_types = {
                'logos': [],
                'photos': [],
                'icons': [],
                'banners': [],
                'other': []
            }
            
            for img_url in all_images:
                # Make URL absolute
                if img_url.startswith('//'):
                    img_url = 'https:' + img_url
                elif img_url.startswith('/'):
                    img_url = urljoin(base_url, img_url)
                elif not img_url.startswith(('http://', 'https://')):
                    img_url = urljoin(base_url, img_url)
                
                # Categorize by filename/URL
                img_lower = img_url.lower()
                if any(word in img_lower for word in ['logo', 'brand']):
                    image_types['logos'].append(img_url)
                elif any(word in img_lower for word in ['photo', 'image', 'img', 'pic']):
                    image_types['photos'].append(img_url)
                elif any(word in img_lower for word in ['icon', 'ico']):
                    image_types['icons'].append(img_url)
                elif any(word in img_lower for word in ['banner', 'header', 'hero']):
                    image_types['banners'].append(img_url)
                else:
                    image_types['other'].append(img_url)
            
            # Create insights for each category
            for category, images in image_types.items():
                if images:
                    insights.append({
                        'category': 'Image',
                        'type': f'{category.title()} Images',
                        'value': ', '.join(images[:3]),  # Limit to 3 images
                        'description': f'Found {len(images)} {category} image(s)',
                        'count': len(images)
                    })
        
        return insights
    
    def detect_technologies(self, html_content, server_info):
        """Detect technologies used by the target"""
        insights = []
        
        # Technology detection patterns
        tech_patterns = {
            'Web Servers': {
                'Apache': ['apache', 'mod_'],
                'Nginx': ['nginx'],
                'IIS': ['iis', 'microsoft-iis'],
                'LiteSpeed': ['litespeed'],
                'Cloudflare': ['cloudflare']
            },
            'CMS/Frameworks': {
                'WordPress': ['wordpress', 'wp-content', 'wp-includes'],
                'Drupal': ['drupal'],
                'Joomla': ['joomla'],
                'Laravel': ['laravel'],
                'Django': ['django'],
                'Ruby on Rails': ['rails', 'ruby'],
                'React': ['react', 'reactjs'],
                'Angular': ['angular', 'ng-'],
                'Vue.js': ['vue', 'vuejs'],
                'Bootstrap': ['bootstrap'],
                'jQuery': ['jquery']
            },
            'Analytics/Tracking': {
                'Google Analytics': ['google-analytics', 'gtag', 'ga('],
                'Facebook Pixel': ['facebook', 'fbq'],
                'Hotjar': ['hotjar'],
                'Google Tag Manager': ['gtm', 'googletagmanager']
            },
            'Security': {
                'Cloudflare': ['cloudflare'],
                'reCAPTCHA': ['recaptcha'],
                'hCaptcha': ['hcaptcha']
            }
        }
        
        content_lower = html_content.lower()
        server_lower = server_info.lower()
        
        for category, technologies in tech_patterns.items():
            detected_techs = []
            for tech_name, patterns in technologies.items():
                for pattern in patterns:
                    if pattern in content_lower or pattern in server_lower:
                        detected_techs.append(tech_name)
                        break
            
            if detected_techs:
                insights.append({
                    'category': 'Technology',
                    'type': category,
                    'value': ', '.join(detected_techs),
                    'description': f'Detected {len(detected_techs)} {category.lower()} technology/ies',
                    'count': len(detected_techs)
                })
        
        return insights
    
    def get_dns_insights(self, hostname, ip_address):
        """Get DNS-related insights"""
        insights = []
        
        try:
            # Reverse DNS lookup
            if ip_address != "Non risolvibile":
                reverse_dns = socket.gethostbyaddr(ip_address)[0]
                if reverse_dns and reverse_dns != hostname:
                    insights.append({
                        'category': 'DNS',
                        'type': 'Reverse DNS',
                        'value': reverse_dns,
                        'description': 'Reverse DNS lookup reveals different hostname',
                        'count': 1
                    })
        except:
            pass
        
        # Check for common DNS records
        try:
            # This would require dnspython library for full DNS queries
            # For now, we'll add basic DNS info
            insights.append({
                'category': 'DNS',
                'type': 'DNS Resolution',
                'value': f'{hostname} → {ip_address}',
                'description': 'Forward DNS resolution information',
                'count': 1
            })
        except:
            pass
        
        return insights
    
    def get_ssl_insights(self, hostname):
        """Get SSL certificate insights"""
        insights = []
        
        try:
            context = ssl.create_default_context()
            with socket.create_connection((hostname, 443), timeout=5) as sock:
                with context.wrap_socket(sock, server_hostname=hostname) as ssock:
                    cert = ssock.getpeercert()
                    if cert and 'notAfter' in cert:
                        insights.append({
                            'category': 'SSL/TLS',
                            'type': 'Certificate Expiry',
                            'value': cert['notAfter'],
                            'description': 'SSL certificate expiration date',
                            'count': 1
                        })
                    
                    # Check certificate issuer
                    if cert and 'issuer' in cert:
                        issuer = cert['issuer']
                        if isinstance(issuer, tuple) and len(issuer) > 0:
                            issuer_name = issuer[0][0][1] if issuer[0] else 'Unknown'
                            insights.append({
                                'category': 'SSL/TLS',
                                'type': 'Certificate Issuer',
                                'value': issuer_name,
                                'description': 'SSL certificate issuing authority',
                                'count': 1
                            })
        except:
            pass
        
        return insights
    
    def discover_subdomains(self, hostname):
        """Discover subdomains using common techniques"""
        base_domain = self.extract_base_domain(hostname)
        if not base_domain:
            return []
        
        # Common subdomains to check
        common_subdomains = [
            '_dmarc', 'api-docs', 'cpanel', 'cpcalendars', 'dev-litespeed',
            'irbis', 'irbis-admin', 'irbis-amm', 'irbis-user-manual',
            'irbispro', 'irbispro-amm', 'irbisproadv', 'kskdjw', 'oldsite',
            'osintcenter-v2', 'user-manual', 'webmail', 'www',
            'api', 'admin', 'blog', 'dev', 'staging', 'test', 'mail',
            'ftp', 'smtp', 'pop', 'imap', 'ns1', 'ns2', 'dns', 'gateway',
            'vpn', 'remote', 'secure', 'ssl', 'cdn', 'static', 'assets',
            'media', 'files', 'download', 'upload', 'backup', 'db', 'mysql',
            'postgres', 'redis', 'elasticsearch', 'kibana', 'grafana',
            'jenkins', 'gitlab', 'github', 'bitbucket', 'jira', 'confluence',
            'wordpress', 'phpmyadmin', 'roundcube', 'squirrelmail'
        ]
        
        discovered_subdomains = []
        
        def check_subdomain(subdomain):
            try:
                full_domain = f"{subdomain}.{base_domain}"
                socket.gethostbyname(full_domain)
                return {
                    'subdomain': subdomain,
                    'full_domain': full_domain,
                    'status': 'active',
                    'type': self.get_subdomain_type(subdomain)
                }
            except socket.gaierror:
                return None
        
        # Use ThreadPoolExecutor for concurrent subdomain checking
        with ThreadPoolExecutor(max_workers=20) as executor:
            future_to_subdomain = {executor.submit(check_subdomain, sub): sub for sub in common_subdomains}
            for future in as_completed(future_to_subdomain):
                result = future.result()
                if result:
                    discovered_subdomains.append(result)
        
        return sorted(discovered_subdomains, key=lambda x: x['subdomain'])
    
    def extract_base_domain(self, hostname):
        """Extract base domain from hostname"""
        parts = hostname.split('.')
        if len(parts) >= 2:
            return '.'.join(parts[-2:])
        return hostname
    
    def get_subdomain_type(self, subdomain):
        """Categorize subdomain by type"""
        subdomain_lower = subdomain.lower()
        
        if any(word in subdomain_lower for word in ['api', 'rest', 'graphql']):
            return 'API'
        elif any(word in subdomain_lower for word in ['admin', 'manage', 'panel']):
            return 'Administration'
        elif any(word in subdomain_lower for word in ['mail', 'smtp', 'pop', 'imap']):
            return 'Email'
        elif any(word in subdomain_lower for word in ['dev', 'test', 'staging']):
            return 'Development'
        elif any(word in subdomain_lower for word in ['cdn', 'static', 'assets']):
            return 'Content Delivery'
        elif any(word in subdomain_lower for word in ['db', 'mysql', 'postgres']):
            return 'Database'
        elif any(word in subdomain_lower for word in ['vpn', 'remote', 'secure']):
            return 'Remote Access'
        elif any(word in subdomain_lower for word in ['www', 'web']):
            return 'Web'
        else:
            return 'Other'
    
    def check_security_headers(self, headers):
        """Check for important security headers"""
        security_headers = {}
        important_headers = [
            'X-Frame-Options',
            'X-Content-Type-Options',
            'X-XSS-Protection',
            'Strict-Transport-Security',
            'Content-Security-Policy',
            'Referrer-Policy',
            'Permissions-Policy'
        ]
        
        for header in important_headers:
            value = headers.get(header, 'Non presente')
            security_headers[header] = value
            
        return security_headers
    
    def scan_vulnerabilities(self, hostname, port, protocol, html_content, security_headers):
        """Scan for common vulnerabilities"""
        vulnerabilities = []
        import re
        # Check for missing security headers
        missing_headers = []
        if security_headers.get('X-Frame-Options') == 'Non presente':
            missing_headers.append('X-Frame-Options')
        if security_headers.get('X-Content-Type-Options') == 'Non presente':
            missing_headers.append('X-Content-Type-Options')
        if security_headers.get('X-XSS-Protection') == 'Non presente':
            missing_headers.append('X-XSS-Protection')
        
        if missing_headers:
            vulnerabilities.append({
                'type': 'Missing Security Headers',
                'severity': 'Medium',
                'description': f'Headers di sicurezza mancanti: {", ".join(missing_headers)}',
                'recommendation': 'Implementare gli header di sicurezza mancanti per proteggere da attacchi XSS, clickjacking e MIME sniffing'
            })
        
        # Check for HTTP instead of HTTPS
        if protocol == 'http':
            vulnerabilities.append({
                'type': 'HTTP Protocol',
                'severity': 'High',
                'description': 'Il sito utilizza HTTP invece di HTTPS',
                'recommendation': 'Implementare HTTPS per crittografare il traffico'
            })
        
        # Check for common server information disclosure
        server_info = security_headers.get('Server', 'Non specificato')
        if server_info != 'Non specificato' and server_info != 'Non presente':
            if any(version in server_info.lower() for version in ['apache', 'nginx', 'iis']):
                vulnerabilities.append({
                    'type': 'Server Information Disclosure',
                    'severity': 'Low',
                    'description': f'Informazioni del server esposte: {server_info}',
                    'recommendation': 'Nascondere o modificare l\'header Server per evitare information disclosure'
                })
        
        # Check for common vulnerable patterns in HTML
        if html_content:
            # Check for inline scripts
            if re.search(r'<script[^>]*>', html_content, re.IGNORECASE):
                vulnerabilities.append({
                    'type': 'Inline Scripts',
                    'severity': 'Medium',
                    'description': 'Script inline rilevati nel codice HTML',
                    'recommendation': 'Utilizzare Content Security Policy per bloccare script inline'
                })
            
            # XSS detection: look for suspicious script tags, event handlers, or suspicious JS code
            xss_patterns = [
                r'<script[^>]*>.*?alert\s*\(',
                r'onerror\s*=\s*"?alert\s*\(',
                r'onload\s*=\s*"?alert\s*\(',
                r'javascript:\s*alert\s*\(',
                r'<img[^>]+onerror=',
                r'<svg[^>]+onload=',
                r'document\.cookie',
                r'localStorage',
                r'sessionStorage',
                r'eval\s*\(',
                r'innerHTML\s*=.*?[''\"]',
                r'location\.hash',
                r'window\.location',
            ]
            for pattern in xss_patterns:
                if re.search(pattern, html_content, re.IGNORECASE|re.DOTALL):
                    vulnerabilities.append({
                        'type': 'Potential XSS',
                        'severity': 'High',
                        'description': 'Possibile vulnerabilità XSS rilevata nel codice HTML o JavaScript',
                        'recommendation': 'Sanificare l\'input utente e utilizzare Content Security Policy (CSP) per mitigare XSS'
                    })
                    break
            
            # SQL injection detection: look for SQL error messages or suspicious patterns
            sql_patterns = [
                r'error.*sql',
                r'mysql.*error',
                r'oracle.*error',
                r'postgresql.*error',
                r'you have an error in your sql syntax',
                r'unclosed quotation mark after the character string',
                r'quoted string not properly terminated',
                r'syntax error.*near',
                r'sql syntax.*?at line',
                r'Warning:.*mysql_',
                r'ODBC SQL Server Driver',
                r'Unclosed quotation mark',
                r'valid MySQL result',
                r'check the manual that corresponds to your MySQL server version',
                r'pg_query\(',
                r'pg_exec\(',
                r'mssql_query\(',
                r'odbc_exec\(',
                r'java\.sql\.SQLException',
            ]
            for pattern in sql_patterns:
                if re.search(pattern, html_content, re.IGNORECASE):
                    vulnerabilities.append({
                        'type': 'Potential SQL Injection',
                        'severity': 'High',
                        'description': 'Possibili errori SQL o pattern sospetti rilevati nella risposta',
                        'recommendation': 'Verificare la presenza di vulnerabilità SQL injection e utilizzare query parametrizzate/preparate'
                    })
                    break
        
        # Check for open ports that might indicate vulnerabilities
        dangerous_ports = [21, 23, 3389]  # FTP, Telnet, RDP
        open_ports = self.scan_common_ports(hostname)
        for port in open_ports:
            if port in dangerous_ports:
                port_names = {21: 'FTP', 23: 'Telnet', 3389: 'RDP'}
                vulnerabilities.append({
                    'type': 'Dangerous Port Open',
                    'severity': 'High',
                    'description': f'Porta {port} ({port_names.get(port, "Unknown")}) aperta',
                    'recommendation': f'Chiudere la porta {port} se non necessaria'
                })
        
        return vulnerabilities
    
    def scan_common_ports(self, hostname):
        """Scan common ports for the given hostname"""
        common_ports = [21, 22, 23, 25, 53, 80, 110, 143, 443, 993, 995, 3306, 3389, 5432, 8080, 8443]
        open_ports = []
        
        def check_port(port):
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(2)
                result = sock.connect_ex((hostname, port))
                sock.close()
                return port if result == 0 else None
            except:
                return None
        
        # Use ThreadPoolExecutor for concurrent port scanning
        with ThreadPoolExecutor(max_workers=10) as executor:
            future_to_port = {executor.submit(check_port, port): port for port in common_ports}
            for future in as_completed(future_to_port):
                port = future.result()
                if port:
                    open_ports.append(port)
        
        return sorted(open_ports)
    
    def send_json_response(self, data):
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(json.dumps(data, indent=2).encode())
    
    def send_error_response(self, error_message):
        self.send_response(500)
        self.send_header('Content-type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(json.dumps({'error': error_message}).encode())

if __name__ == '__main__':
    PORT = 3000
    
    with socketserver.TCPServer(("", PORT), EchoTraceHandler) as httpd:
        print(f"🚀 EchoTrace operativo su http://localhost:{PORT}")
        print(f"📱 Apri il browser e vai su http://localhost:{PORT}")
        print("🔍 Scansione avanzata: IP, Hostname, Porte, Vulnerabilità, Titoli")
        print("🛡️  Rilevamento vulnerabilità attivo")
        print("🌐 Scoperta subdomain in stile Shodan")
        print("💡 Insights aggiuntivi attivi")
        print("📧 Estrazione email, domini, IP, social, immagini")
        print("Premi Ctrl+C per fermare il server")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\n�� Server fermato") 