#!/usr/bin/env python3
try:
    from flask import Flask, request, jsonify, send_from_directory
except ImportError:
    raise ImportError("Flask is not installed. Please install it with 'pip install flask'.")

try:
    import requests
except ImportError:
    raise ImportError("Requests is not installed. Please install it with 'pip install requests'.")

try:
    from bs4 import BeautifulSoup
except ImportError:
    raise ImportError("BeautifulSoup4 is not installed. Please install it with 'pip install beautifulsoup4'.")

import os

app = Flask(__name__)

@app.route('/')
def index():
    return send_from_directory('.', 'index.html')

@app.route('/<path:filename>')
def static_files(filename):
    return send_from_directory('.', filename)

@app.route('/api/scan')
def scan_url():
    url = request.args.get('url')
    if not url:
        return jsonify({'error': 'URL mancante'}), 400
    
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()
        
        soup = BeautifulSoup(response.text, 'html.parser')
        titles = []
        
        # Extract headings (h1, h2, h3)
        for tag in soup.find_all(['h1', 'h2', 'h3']):
            text = tag.get_text().strip()
            if text:
                titles.append(text)
        
        return jsonify({'titles': titles})
    
    except requests.RequestException as e:
        print(f"Errore durante la scansione: {e}")
        return jsonify({'error': f'Errore durante l\'analisi: {str(e)}'}), 500
    except Exception as e:
        print(f"Errore generico: {e}")
        return jsonify({'error': f'Errore generico: {str(e)}'}), 500

if __name__ == '__main__':
    print("🚀 EchoTrace operativo su http://localhost:3000")
    print("📱 Apri il browser e vai su http://localhost:3000")
    app.run(host='0.0.0.0', port=3000, debug=True) 